console.log('RLB - main.js for DWP - version 1.0.6');

let host_base = window.location.origin.replace(':8008', '');
const server_endpoint = host_base + ":3000/server-endpoint";
const cec_config = host_base + ":3000/cec-config";
const server_screenshot = host_base + ":3000/";
const server_custom_command = host_base + ":3000/send-custom-command";
const server_setValues = host_base + ":3000/proxy-setuservar";
const customCommands = [];
let userVars = []; // Array of { name, value }
const lockedButtons = new Set();
let udpCommands = [];
const server_udp_command = host_base + ":3000/send-udp-command";
const udp_config = host_base + ":3000/udp-config";


document.addEventListener("DOMContentLoaded", function () {
    console.log("RLB Device Web Page 1.0.6");
    fetchInitialData();
    getCurrentStatusUserVar();
    fetchInitialUdpCommands();
});


function getCurrentTimestamp() {
    return new Date().toLocaleString(); 
}


function fetchInitialData() {
    $.ajax({
        url: server_endpoint,
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({ message: "View" }),
        success: function(response) {
            console.log('EDID Data Success:', response);
            if (response.status === "success") {
                displayEdidData(response);
            }
        },
        error: function(error) {
            console.error('Error fetching EDID data:', error);
        }
    });

    $.ajax({
        url: server_endpoint,
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({ message: "Refresh HDMI Status" }),
        success: function(response) {
            console.log('HDMI Status Success:', response);
            if (response.status === "success") {
                displayHdmiStatus(response);
            }
        },
        error: function(error) {
            console.error('Error fetching HDMI status:', error);
        }
    });

    // Fetch saved CEC commands from config file on server
    $.ajax({
        url: cec_config,
        type: 'GET',
        success: function(response) {
            if (response.status === "success" && response.config?.cec_config?.length) {
                const savedCommands = response.config.cec_config[0]; // single object with keys
                for (const [name, value] of Object.entries(savedCommands)) {
                    customCommands.push({ name, value });
                }
                renderCustomCommands();
            } else {
                console.warn('No saved CEC commands found.');
            }
        },
        error: function(error) {
            console.error('Error fetching CEC config:', error);
        }
    });

    // Fetch UDP commands from config
    $.ajax({
        url: udp_config,
        type: 'GET',
        success: function (response) {
            if (response.udp_commands && Array.isArray(response.udp_commands) && response.udp_commands.length) {
              udpCommands = response.udp_commands.map(cmd => ({
                name: cmd.name,
                payload: cmd.value,
                port: cmd.port
              }));
              renderUdpCommands();
            } else {
              console.warn('No UDP commands found.');
            }
          },
        error: function (err) {
        console.error('Failed to load UDP config:', err);
        }
    });

}


function sendPostRequest(button, retry = true, originalBackground = null) {
    const message = $(button).text();
    console.log('Button clicked:', message);

    // Block new user-initiated clicks
    if (retry && lockedButtons.has(button)) {
        console.warn(` Ignored click on "${message}" during retry lock.`);
        return;
    }

    // Lock only on first attempt
    if (retry) {
        lockedButtons.add(button);
        button.classList.add('button-flashing'); // 🔄 Start flashing
    }

    if (originalBackground === null) {
        originalBackground = button.style.backgroundColor || '';
    }

    button.disabled = true;

    $.ajax({
        url: server_endpoint,
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({ message }),
        success: function (response, textStatus, xhr) {
            const statusCode = xhr.status;
            const responseText = response.message || JSON.stringify(response);
            const timestamp = getCurrentTimestamp();

            console.log(` Success [${statusCode}] for "${message}"`);

            // Restore visual and logic state
            button.disabled = false;
            button.classList.remove('button-flashing');
            button.style.backgroundColor = originalBackground;
            lockedButtons.delete(button);

            if (["Power Save Mode ON", "Power Save Mode OFF", "CEC Display ON", "CEC Display OFF", "CEC Source HDMI1", "CEC Source HDMI2", "CEC Source Active"].includes(message)) {
                updateLastPressedButton(message);
                document.getElementById('last-button-pressed-status').innerHTML = `
                    <strong>Status Code:</strong> ${statusCode}<br>
                    <strong>Response:</strong> ${responseText}<br>
                    <strong>Timestamp last update:</strong> ${timestamp}
                `;
            }

            if (message === "View") {
                if (response.status === "success") {
                    displayEdidData(response);
                    document.getElementById('edid-status').innerHTML = `
                        <strong>Status Code:</strong> ${statusCode}<br>
                        <strong>Response:</strong> ${response.status}<br>
                        <strong>Timestamp last update:</strong> ${timestamp}
                    `;
                } else {
                    document.getElementById('edid-info').innerHTML = `<span style="color: red;">EDID data unavailable</span>`;
                    document.getElementById('edid-status').innerHTML = `
                        <strong>Status Code:</strong> ${statusCode}<br>
                        <strong>Error:</strong> ${JSON.stringify(response, null, 2)}<br>
                        <strong>Timestamp last update:</strong> ${timestamp}
                    `;
                }
            }

            if (message === "Refresh HDMI Status" && response.status === "success") {
                displayHdmiStatus(response);
                document.getElementById('hdmi-status-status').innerHTML = `
                    <strong>Status Code:</strong> ${statusCode}<br>
                    <strong>Response:</strong> ${response.status}<br>
                    <strong>Timestamp last update:</strong> ${timestamp}
                `;
            }

            if (message === "New Screenshot" && response.status === "success") {
                updateScreenshotImage();
            }
        },
        error: function (xhr, textStatus, errorThrown) {
            const statusCode = xhr.status;
            const responseText = xhr.responseText || errorThrown;
            const timestamp = getCurrentTimestamp();

            console.warn(` Error [${statusCode}] for "${message}"`);

            if (statusCode === 500 && retry) {
                console.warn(` Retrying "${message}" in 1 second...`);

                // Keep button red & retry once
                setTimeout(() => {
                    sendPostRequest(button, false, originalBackground);
                }, 1000);
                return;
            }

            // Final failure — restore state
            button.disabled = false;
            button.classList.remove('button-flashing');
            button.style.backgroundColor = originalBackground;
            lockedButtons.delete(button);

            if (["Power Save Mode ON", "Power Save Mode OFF", "CEC Display ON", "CEC Display OFF", "CEC Source HDMI1", "CEC Source HDMI2", "CEC Source Active"].includes(message)) {
                document.getElementById('last-button-pressed-status').innerHTML = `
                    <strong>Status Code:</strong> ${statusCode}<br>
                    <strong>Error:</strong> ${responseText}<br>
                    <strong>Timestamp last update:</strong> ${timestamp}
                `;
            }

            if (message === "View") {
                document.getElementById('edid-info').innerHTML = `<span style="color: red;">EDID request failed (network or server error)</span>`;
                document.getElementById('edid-status').innerHTML = `
                    <strong>Status Code:</strong> ${statusCode}<br>
                    <strong>Error:</strong> ${responseText}<br>
                    <strong>Timestamp last update:</strong> ${timestamp}
                `;
            }

            if (message === "Refresh HDMI Status") {
                document.getElementById('hdmi-status-status').innerHTML = `
                    <strong>Status Code:</strong> ${statusCode}<br>
                    <strong>Error:</strong> ${responseText}<br>
                    <strong>Timestamp last update:</strong> ${timestamp}
                `;
            }
        }
    });
}


function updateLastPressedButton(buttonName) {
    let buttonInfo = `<strong>Last Pressed Button:</strong> ${buttonName} <br>`;
    document.getElementById("last-button-pressed").innerHTML = buttonInfo;
}


function displayEdidData(data) {
    let edidInfo = `
        <strong>Manufacturer:</strong> ${data.manufacturer} <br>
        <strong>Monitor Name:</strong> ${data.monitorName} <br>
        <strong>Year of Manufacture:</strong> ${data.yearOfManufacture} <br>
        <strong>Serial Number:</strong> ${data.serialNumber} <br>
        <strong>HDR ST2084 Support:</strong> ${data.hdrSt2084Support} <br>
        <strong>BT.2020 RGB Support:</strong> ${data.bt2020RgbSupport} <br>
        <strong>BT.2020 YCC Support:</strong> ${data.bt2020YccSupport} <br>
        <strong>SDR EOTF Support:</strong> ${data.sdrEotfSupport} <br>
    `;
    $("#edid-info").html(edidInfo);
}


function displayHdmiStatus(data) {
    let powerSaveStatus = "Unknown";

    if (data.powerSaveMode === 1 || data.powerSaveMode === true) {
        powerSaveStatus = "Power Save Mode Enabled";
    } else if (data.powerSaveMode === 0 || data.powerSaveMode === false) {
        powerSaveStatus = "Power Save Mode Disabled";
    } else {
        powerSaveStatus = `Unrecognized value (${data.powerSaveMode})`;
    }

    const hdmiInfo = `
        <strong>Power Save Mode:</strong> ${powerSaveStatus} <br>
        <strong>HDMI Connector Attached:</strong> ${data.hdmiAttached} <br>
        <strong>Output Powered:</strong> ${data.outputStatus.outputPowered} <br>
        <strong>Output Present:</strong> ${data.outputStatus.outputPresent} <br>
        <strong>Audio Format:</strong> ${data.outputStatus.audioFormat} <br>
        <strong>Audio Channel Count:</strong> ${data.outputStatus.audioChannelCount} <br>
        <strong>Audio Bits Per Sample:</strong> ${data.outputStatus.audioBitsPerSample} <br>
        <strong>Audio Sample Rate:</strong> ${data.outputStatus.audioSampleRate} <br>
        <strong>EOTF:</strong> ${data.outputStatus.eotf} <br>
    `;

    $("#output-status-info").html(hdmiInfo);
}


function updateScreenshotImage() {
    let imgElement = document.getElementById("screenshot-image");
    imgElement.src = server_screenshot + "screen.jpg?" + new Date().getTime(); // Cache-busting to load new image
    imgElement.style.display = "block";

    // Get or create the timestamp element
    let timestampElement = document.getElementById("timestamp-info");
    if (!timestampElement) {
        timestampElement = document.createElement("p");
        timestampElement.id = "timestamp-info";
        imgElement.insertAdjacentElement("afterend", timestampElement);
    }
    
    // Update the timestamp text
    timestampElement.textContent = `Last Updated: ${new Date().toLocaleString()}`;
}


function getCurrentStatusUserVar() {
    const refreshBtn = document.getElementById('refresh-user-vars');
    if (refreshBtn) {
        refreshBtn.classList.add('button-flashing');
        refreshBtn.disabled = true;
    }

    let targeturl = "/GetUserVars";
    console.log(targeturl);

    fetch(targeturl)
        .then(response => response.text())
        .then(function(xmlString) {
            let parser = new DOMParser();
            let xmlDoc = parser.parseFromString(xmlString, "text/xml");
            console.log("xmlDoc", xmlDoc);

            let variables = xmlDoc.getElementsByTagName("BrightSignVar");
            userVars = [];

            for (let i = 0; i < variables.length; i++) {
                let name = variables[i].getAttribute("name");
                let value = variables[i].textContent;
                userVars.push({ name, value });
            }

            renderUserVars();
        })
        .catch(function(error) {
            console.error("Error fetching UserVar:", error);
            document.getElementById("output-uservariable-info").innerHTML = `
                <span style="color:red;">Failed to load user variables.</span>
            `;
        })
        .finally(() => {
            if (refreshBtn) {
                refreshBtn.classList.remove('button-flashing');
                refreshBtn.disabled = false;
            }
        });
}


function renderUserVars() {
    const container = document.getElementById('output-uservariable-info');
    container.innerHTML = '';

    const title = document.createElement('div');
    title.innerHTML = `<strong>Presentation User Variables:</strong><br><br>`;
    container.appendChild(title);

    userVars.forEach((varObj, index) => {
        const wrapper = document.createElement('div');
        wrapper.style.display = 'flex';
        wrapper.style.alignItems = 'center';
        wrapper.style.gap = '10px';
        wrapper.style.marginBottom = '10px';
        wrapper.setAttribute('data-varname', varObj.name);

        const nameField = document.createElement('input');
        nameField.type = 'text';
        nameField.value = varObj.name;
        nameField.disabled = true;
        nameField.style.width = '150px';

        const valueField = document.createElement('input');
        valueField.type = 'text';
        valueField.value = varObj.value;
        valueField.classList.add('user-var-input');
        valueField.dataset.name = varObj.name;
        valueField.style.width = '150px';
        valueField.oninput = () => {
            userVars[index].value = valueField.value.trim();
        };

        const saveBtn = document.createElement('button');
        saveBtn.textContent = 'Save';
        saveBtn.onclick = () => {
            const newValue = valueField.value.trim();
            setSingleUserVar(varObj.name, newValue, saveBtn);
        };

        const upBtn = document.createElement('button');
        upBtn.textContent = '↑';
        upBtn.onclick = () => moveUserVar(index, -1);

        const downBtn = document.createElement('button');
        downBtn.textContent = '↓';
        downBtn.onclick = () => moveUserVar(index, 1);

        wrapper.appendChild(nameField);
        wrapper.appendChild(valueField);
        wrapper.appendChild(saveBtn);
        wrapper.appendChild(upBtn);
        wrapper.appendChild(downBtn);

        container.appendChild(wrapper);
    });

    const timestamp = document.createElement('div');
    timestamp.innerHTML = `<strong>Last Updated:</strong> ${new Date().toLocaleString()}`;
    container.appendChild(timestamp);
}


function moveUserVar(index, direction) {
    const newIndex = index + direction;
    if (newIndex < 0 || newIndex >= userVars.length) return;

    // Swap entries
    const temp = userVars[index];
    userVars[index] = userVars[newIndex];
    userVars[newIndex] = temp;

    renderUserVars();
}


function addCustomCommand() {
    const nameInput = document.getElementById('custom-command-name');
    const valueInput = document.getElementById('custom-command-value');
    const name = nameInput.value.trim();
    const value = valueInput.value.trim();

    if (!name || !value) {
        alert('Please enter both a command name and command text.');
        return;
    }

    customCommands.push({ name, value });
    renderCustomCommands();
    saveCommandsToServer();

    nameInput.value = '';
    valueInput.value = '';
}


function renderCustomCommands() {
    const container = document.getElementById('custom-command-list');
    container.innerHTML = '';

    customCommands.forEach((cmd, index) => {
        const wrapper = document.createElement('div');
        wrapper.style.display = 'flex';
        wrapper.style.alignItems = 'center';
        wrapper.style.gap = '10px';
        wrapper.style.marginBottom = '10px';

        const nameInput = document.createElement('input');
        nameInput.type = 'text';
        nameInput.value = cmd.name;
        nameInput.style.width = '120px';
        nameInput.onchange = () => {
            customCommands[index].name = nameInput.value.trim();
            saveCommandsToServer();
        };

        const valueInput = document.createElement('input');
        valueInput.type = 'text';
        valueInput.value = cmd.value;
        valueInput.style.width = '120px';
        valueInput.onchange = () => {
            customCommands[index].value = valueInput.value.trim();
            saveCommandsToServer();
        };

        const sendBtn = document.createElement('button');
        sendBtn.textContent = 'Send Command';
        sendBtn.onclick = () => {
            //sendCustomCommand(cmd.value, cmd.name);
            sendCustomCommand(cmd.value, cmd.name, sendBtn);
        };

        const deleteBtn = document.createElement('button');
        deleteBtn.textContent = 'Delete';
        deleteBtn.style.backgroundColor = '#dc3545';
        deleteBtn.style.color = 'white';
        deleteBtn.onclick = () => {
            const confirmed = confirm(`Are you sure you want to delete the command "${cmd.name}"?`);
            if (confirmed) {
                customCommands.splice(index, 1);
                renderCustomCommands();
                saveCommandsToServer();
            }
        };

        const moveUpBtn = document.createElement('button');
        moveUpBtn.textContent = '↑';
        moveUpBtn.onclick = () => moveCommand(index, -1);

        const moveDownBtn = document.createElement('button');
        moveDownBtn.textContent = '↓';
        moveDownBtn.onclick = () => moveCommand(index, 1);

        wrapper.appendChild(nameInput);
        wrapper.appendChild(valueInput);
        wrapper.appendChild(sendBtn);
        wrapper.appendChild(deleteBtn);
        wrapper.appendChild(moveUpBtn);
        wrapper.appendChild(moveDownBtn);

        container.appendChild(wrapper);
    });
}

function sendCustomCommand(commandValue, commandName, button = null, retry = true, originalBackground = null) {
    console.log('Sending custom command:', commandValue);
    const timestamp = getCurrentTimestamp();

    // Store original button background only once
    if (button && originalBackground === null) {
        originalBackground = button.style.backgroundColor || '';
        button.classList.add('button-flashing');
        button.disabled = true;
    }

    $.ajax({
        url: server_custom_command,
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({ command: commandValue, name: commandName }),
        success: function(response, textStatus, xhr) {
            const statusCode = xhr.status;
            const responseText = response.message || JSON.stringify(response);

            document.getElementById('last-custom-button-pressed').innerHTML = `
                <strong>Last custom command sent:</strong> ${commandName}<br>
                <strong>Timestamp:</strong> ${timestamp}
            `;

            document.getElementById('last-custom-button-pressed-status').innerHTML = `
                <strong>Status Code:</strong> ${statusCode}<br>
                <strong>Response:</strong> ${responseText}<br>
                <strong>Timestamp last update:</strong> ${timestamp}
            `;
        },
        error: function(xhr, textStatus, errorThrown) {
            const statusCode = xhr.status;
            const responseText = xhr.responseText || errorThrown;

            document.getElementById('last-custom-button-pressed').innerHTML = `
                <strong>Last custom command sent:</strong> ${commandName}<br>
                <strong>Timestamp:</strong> ${timestamp}
            `;

            document.getElementById('last-custom-button-pressed-status').innerHTML = `
                <strong>Status Code:</strong> ${statusCode}<br>
                <strong>Error:</strong> ${responseText}<br>
                <strong>Timestamp last update:</strong> ${timestamp}
            `;

            if (statusCode === 500 && retry) {
                console.warn(` Custom command "${commandName}" failed (500). Retrying in 1 second...`);
                setTimeout(() => {
                    sendCustomCommand(commandValue, commandName, button, false, originalBackground);
                }, 1000);
                return; // Prevent reset for retry
            }
        },
        complete: function() {
            if (button) {
                button.classList.remove('button-flashing');
                button.disabled = false;
                button.style.backgroundColor = originalBackground;
            }
        }
    });
}


function saveCommandsToServer() {
    const commandsToSave = {};
    customCommands.forEach(cmd => {
        commandsToSave[cmd.name] = cmd.value;
    });

    $.ajax({
        url: cec_config,
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({ commands: commandsToSave }),
        success: function(response) {
            console.log('Config saved:', response);
        },
        error: function(err) {
            console.error('Error saving config:', err);
        }
    });
}


function moveCommand(index, direction) {
    const newIndex = index + direction;

    if (newIndex < 0 || newIndex >= customCommands.length) return;

    // Swap the items
    const temp = customCommands[index];
    customCommands[index] = customCommands[newIndex];
    customCommands[newIndex] = temp;

    renderCustomCommands();
    saveCommandsToServer();
}


function showSuccessIndicator(varName) {
    const wrapper = document.querySelector(`[data-varname="${varName}"]`);
    if (!wrapper) return;

    let indicator = wrapper.querySelector('.success-indicator');
    if (!indicator) {
        indicator = document.createElement('span');
        indicator.className = 'success-indicator';
        indicator.textContent = '✓';
        indicator.style.color = 'green';
        indicator.style.fontWeight = 'bold';
        indicator.style.marginLeft = '8px';
        wrapper.appendChild(indicator);
    }

    indicator.style.display = 'inline';

    setTimeout(() => {
        indicator.style.display = 'none';
    }, 2000);
}


function setSingleUserVar(name, value, button = null) {
    const payload = {};
    payload[name] = value;

    if (button) {
        button.classList.add('button-flashing');
        button.disabled = true;
    }

    $.ajax({
        url: server_setValues,
        method: 'POST',
        contentType: 'application/x-www-form-urlencoded',
        data: $.param(payload),
        success: function () {
            console.log(` Saved ${name} = ${value}`);
            showSuccessIndicator(name);
            getCurrentStatusUserVar();
        },
        error: function (xhr, status, error) {
            const code = xhr.status;
            const timestamp = getCurrentTimestamp();

            if (code === 302) {
                console.warn(` Redirect (302) occurred, likely saved`);
                return;
            }

            console.error(` Error saving ${name}:`, error);
        },
        complete: function () {
            if (button) {
                button.classList.remove('button-flashing');
                button.disabled = false;
            }
        }
    });
}


function saveAllUserVars(varsArray, callback = () => {}, button = null) {
    const payload = {};

    varsArray.forEach(({ name, value }) => {
        payload[name] = value;
    });

    $.ajax({
        url: server_setValues,
        method: 'POST',
        contentType: 'application/x-www-form-urlencoded',
        data: $.param(payload),
        success: function () {
            console.log(" All variables saved");
            document.querySelectorAll('.user-var-input').forEach(input => {
                showSuccessIndicator(input.dataset.name);
            });
            getCurrentStatusUserVar();
        },
        error: function (xhr, status, error) {
            const code = xhr.status;
            const timestamp = getCurrentTimestamp();

            if (code === 302) {
                console.warn(` Redirect (302) occurred, likely saved`);
                console.log(" All variables saved (302 redirect)");
            } else {
                console.error(" Error saving variables:", error);
            }
        },
        complete: function () {
            if (button) {
                button.classList.remove('button-flashing');
                button.disabled = false;
            }
            callback();
        }
    });
}


function saveAllUserVarButton() {
    const saveAllBtn = document.getElementById('save-all-user-vars');
    const inputs = document.querySelectorAll('.user-var-input');
    const allVars = [];

    inputs.forEach(input => {
        const name = input.dataset.name;
        const value = input.value;
        if (name) {
            allVars.push({ name, value });
        }
    });

    if (saveAllBtn) {
        saveAllBtn.classList.add('button-flashing');
        saveAllBtn.disabled = true;
    }

    saveAllUserVars(allVars, () => {
        if (saveAllBtn) {
            saveAllBtn.classList.remove('button-flashing');
            saveAllBtn.disabled = false;
        }
    });
}


function cleanupAfterRequest(button, originalBackground) {
    button.disabled = false;
    button.style.backgroundColor = originalBackground;
    button.classList.remove('button-flashing');
    lockedButtons.delete(button);
}


function renderUdpCommands() {
    const container = document.getElementById('udp-command-list');
    container.innerHTML = '';
  
    udpCommands.forEach((cmd, index) => {
      const wrapper = document.createElement('div');
      wrapper.style.display = 'flex';
      wrapper.style.alignItems = 'center';
      wrapper.style.gap = '10px';
      wrapper.style.marginBottom = '10px';
  
      const nameInput = document.createElement('input');
      nameInput.type = 'text';
      nameInput.value = cmd.name;
      nameInput.placeholder = "Command Name";
      nameInput.style.width = '120px';
      nameInput.oninput = () => {
        udpCommands[index].name = nameInput.value.trim();
        saveUdpCommandsToServer();
      };
  
      const payloadInput = document.createElement('input');
      payloadInput.type = 'text';
      payloadInput.value = cmd.payload || cmd.value || '';
      payloadInput.placeholder = "Payload";
      payloadInput.style.width = '120px';
      payloadInput.oninput = () => {
        udpCommands[index].payload = payloadInput.value.trim();
        saveUdpCommandsToServer();
      };
  
      const portInput = document.createElement('input');
      portInput.type = 'number';
      portInput.value = cmd.port || 5000;
      portInput.placeholder = "Port";
      portInput.style.width = '80px';
      portInput.oninput = () => {
        udpCommands[index].port = parseInt(portInput.value.trim()) || 5000;
        saveUdpCommandsToServer();
      };
  
      const sendBtn = document.createElement('button');
      sendBtn.textContent = 'Send UDP';
      sendBtn.onclick = () => {
        sendUdpCommand(cmd.name, cmd.payload, cmd.port, sendBtn);
      };
  
      const deleteBtn = document.createElement('button');
      deleteBtn.textContent = 'Delete';
      deleteBtn.style.backgroundColor = '#dc3545';
      deleteBtn.style.color = 'white';
      deleteBtn.onclick = () => {
        const confirmed = confirm(`Are you sure you want to delete "${cmd.name}"?`);
        if (confirmed) {
          udpCommands.splice(index, 1);
          renderUdpCommands();
          saveUdpCommandsToServer();
        }
      };
  
      const moveUpBtn = document.createElement('button');
      moveUpBtn.textContent = '↑';
      moveUpBtn.onclick = () => {
        if (index > 0) {
          [udpCommands[index - 1], udpCommands[index]] = [udpCommands[index], udpCommands[index - 1]];
          renderUdpCommands();
          saveUdpCommandsToServer();
        }
      };
  
      const moveDownBtn = document.createElement('button');
      moveDownBtn.textContent = '↓';
      moveDownBtn.onclick = () => {
        if (index < udpCommands.length - 1) {
          [udpCommands[index + 1], udpCommands[index]] = [udpCommands[index], udpCommands[index + 1]];
          renderUdpCommands();
          saveUdpCommandsToServer();
        }
      };
  
      wrapper.appendChild(nameInput);
      wrapper.appendChild(payloadInput);
      wrapper.appendChild(portInput);
      wrapper.appendChild(sendBtn);
      wrapper.appendChild(deleteBtn);
      wrapper.appendChild(moveUpBtn);
      wrapper.appendChild(moveDownBtn);
  
      container.appendChild(wrapper);
    });
  }
  

  function addUdpCommand() {
    const nameInput = document.getElementById('udp-command-name');
    const payloadInput = document.getElementById('udp-command-value');
    const portInput = document.getElementById('udp-command-port');
  
    const name = nameInput.value.trim();
    const payload = payloadInput.value.trim();
    const port = parseInt(portInput.value.trim(), 10);
  
    // 🚨 Validate before adding
    if (!name || !payload || isNaN(port)) {
      alert("Please enter a name, payload, and a valid port number.");
      return;
    }
  
    udpCommands.push({ name, payload, port });
  
    renderUdpCommands();
    saveUdpCommandsToServer();
  
    nameInput.value = '';
    payloadInput.value = '';
    portInput.value = '';
  }
  

function moveUdpCommand(index, direction) {
    const newIndex = index + direction;
    if (newIndex < 0 || newIndex >= udpCommands.length) return;
    const temp = udpCommands[index];
    udpCommands[index] = udpCommands[newIndex];
    udpCommands[newIndex] = temp;
    renderUdpCommands();
}


function sendUdpCommand(name, payload, port = 5000, button = null) {
    const timestamp = getCurrentTimestamp();
  
    if (button) {
      button.classList.add('button-flashing');
      button.disabled = true;
    }
  
    $.ajax({
      url: server_udp_command,
      type: 'POST',
      contentType: 'application/json',
      data: JSON.stringify({ payload, port }), // only send payload and port
      success: function (response, textStatus, xhr) {
        const statusCode = xhr.status;
        const responseText = response.message || JSON.stringify(response);
  
        document.getElementById('last-udp-button-pressed').innerHTML = `
          <strong>Last UDP command sent:</strong> ${name}<br>
          <strong>Port:</strong> ${port}<br>
          <strong>Timestamp:</strong> ${timestamp}
        `;
        document.getElementById('last-udp-button-status').innerHTML = `
          <strong>Status Code:</strong> ${statusCode}<br>
          <strong>Response:</strong> ${responseText}<br>
          <strong>Timestamp:</strong> ${timestamp}
        `;
      },
      error: function (xhr, status, error) {
        const statusCode = xhr.status;
        const responseText = xhr.responseText || error;
  
        document.getElementById('last-udp-button-pressed').innerHTML = `
          <strong>Last UDP command sent:</strong> ${name}<br>
          <strong>Port:</strong> ${port}<br>
          <strong>Timestamp:</strong> ${timestamp}
        `;
        document.getElementById('last-udp-button-status').innerHTML = `
          <strong>Status Code:</strong> ${statusCode}<br>
          <strong>Error:</strong> ${responseText}<br>
          <strong>Timestamp:</strong> ${timestamp}
        `;
      },
      complete: function () {
        if (button) {
          button.classList.remove('button-flashing');
          button.disabled = false;
        }
      }
    });
}

function fetchInitialUdpCommands() {
    $.ajax({
      url: udp_config,
      type: "GET",
      success: function (response) {
        if (response.status === "success" && response.config?.udp_commands) {
          udpCommands.push(...response.config.udp_commands);
          renderUdpCommands();
        }
      },
      error: function (err) {
        console.warn(" Failed to load saved UDP commands");
      }
    });
}


function saveUdpCommandsToServer() {
    const payload = {
      udp_commands: udpCommands.map(cmd => ({
        name: cmd.name,
        value: cmd.payload || cmd.value,
        port: cmd.port
      }))
    };
  
    console.log(" Saving to server:", payload);
  
    $.ajax({
      url: udp_config,
      type: 'POST',
      contentType: 'application/json',
      data: JSON.stringify(payload),
      success: function (res) {
        console.log(' UDP config saved successfully.');
      },
      error: function (err) {
        console.error(' Failed to save UDP config:', err);
      }
    });
  }